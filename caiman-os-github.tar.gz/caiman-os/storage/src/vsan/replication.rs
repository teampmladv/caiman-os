//! vsan/replication.rs — stub
