//! vsan/nvmeof.rs — stub
