//! vsan/csi.rs — stub
