//! vsan/policy.rs — stub
