//! vvols/iscsi.rs — stub
