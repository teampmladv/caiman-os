//! vvols/nfs.rs — stub
