//! vvols/nvmeof.rs — stub
