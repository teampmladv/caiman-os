# API Reference

Base URL: `http://localhost:8765` (or `https://api.caimanos.com`)

All requests and responses use JSON. No authentication required in single-node mode.

---

## Health

### GET /health

```bash
curl http://localhost:8765/health
```

```json
{
  "status": "ok",
  "version": "0.7.0",
  "service": "caiman-api",
  "demo": false
}
```

---

## Virtual Machines

### POST /api/vms — Create VM

Spawns a new `caiman-vmm` process and writes state to `/var/run/caiman/{id}.json`.

```bash
curl -X POST http://localhost:8765/api/vms \
  -H 'Content-Type: application/json' \
  -d '{
    "name":    "web-01",
    "cpus":    2,
    "memMib":  512,
    "kernel":  "/var/lib/caiman/vmlinuz",
    "disk":    "/var/lib/caiman/disks/web-01.img",
    "uplink":  "eth0",
    "cmdline": "console=ttyS0,115200 reboot=k panic=1",
    "labels":  { "env": "prod", "app": "nginx" }
  }'
```

**Request body:**

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `name` | string | ✓ | — | VM name |
| `cpus` | integer | — | 1 | Number of vCPUs |
| `memMib` | integer | — | 256 | RAM in MiB |
| `kernel` | string | — | `/boot/vmlinuz` | Path to bzImage |
| `disk` | string | — | null | Path to raw disk image |
| `uplink` | string | — | `eth0` | Host NIC for XDP |
| `cmdline` | string | — | `console=ttyS0,115200 reboot=k panic=1 nomodules` | Kernel cmdline |
| `labels` | object | — | `{}` | Key-value labels |

**Response (201 Created):**

```json
{
  "id":          "vm-a1b2c3d4",
  "name":        "web-01",
  "status":      "RUNNING",
  "pid":         31337,
  "cpus":        2,
  "memMib":      512,
  "nodeName":    "caiman-node-01",
  "kernel":      "/var/lib/caiman/vmlinuz",
  "disk":        "/var/lib/caiman/disks/web-01.img",
  "mac":         "02:aa:bb:00:00:01",
  "uplink":      "eth0",
  "labels":      { "env": "prod", "app": "nginx" },
  "createdAt":   "2026-04-29T10:00:00Z",
  "startedAt":   "2026-04-29T10:00:01Z",
  "cpuUsagePct": 0.0,
  "memUsedMib":  0,
  "netRxMbps":   0.0,
  "netTxMbps":   0.0,
  "uptimeSecs":  0
}
```

---

### GET /api/vms — List VMs

Returns all VMs. Reconciles status (marks STOPPED if process died).

```bash
curl http://localhost:8765/api/vms | jq .
```

**Response (200):** Array of VM objects (same schema as above).

---

### GET /api/vms/:id — Get VM

```bash
curl http://localhost:8765/api/vms/vm-a1b2c3d4
```

**Response (200):** VM object. **404** if not found.

---

### POST /api/vms/:id/start — Start VM

Re-spawns a stopped VM with the same configuration.

```bash
curl -X POST http://localhost:8765/api/vms/vm-a1b2c3d4/start
```

**Response (200):** Updated VM object with new PID and `status: "RUNNING"`.

---

### POST /api/vms/:id/stop — Stop VM (graceful)

Sends `SIGTERM` to the caiman-vmm process.

```bash
curl -X POST http://localhost:8765/api/vms/vm-a1b2c3d4/stop
```

**Response (200):** VM object with `status: "STOPPED"`.

---

### POST /api/vms/:id/force-stop — Force stop

Sends `SIGKILL` to the caiman-vmm process. Use when graceful stop hangs.

```bash
curl -X POST http://localhost:8765/api/vms/vm-a1b2c3d4/force-stop
```

**Response (200):** VM object with `status: "STOPPED"`.

---

### DELETE /api/vms/:id — Delete VM

Force-stops the VM, removes the state file and log file.

```bash
curl -X DELETE http://localhost:8765/api/vms/vm-a1b2c3d4
```

**Response (204 No Content)**

---

### GET /api/vms/:id/console — Serial console log

Returns the last 200 lines of the VM's serial console output (ttyS0).

```bash
curl http://localhost:8765/api/vms/vm-a1b2c3d4/console | jq .
```

**Response (200):** Array of strings (log lines, newest first).

```json
[
  "login: ",
  "Caimán OS 0.7.0",
  "[    0.210000] caiman-vmm: vm-001 running",
  "[    0.198441] EXT4-fs (vda1): mounted filesystem",
  "..."
]
```

---

### POST /api/vms/:id/migrate — Live migrate

Starts a live migration to another node. Spawns `caiman-livemig`.

```bash
curl -X POST http://localhost:8765/api/vms/vm-a1b2c3d4/migrate \
  -H 'Content-Type: application/json' \
  -d '{ "destination": "192.168.1.42" }'
```

**Request body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `destination` | string | ✓ | IP or hostname of destination node |

**Response (200):**
```json
{
  "status": "migrated",
  "destination": "192.168.1.42"
}
```

---

## Cluster & Nodes

### GET /api/nodes — Node metrics

Returns real metrics from `/proc` via sysinfo.

```bash
curl http://localhost:8765/api/nodes | jq .
```

**Response (200):** Array of node objects.

```json
[
  {
    "hostname":      "caiman-node-01",
    "status":        "HEALTHY",
    "cpuCores":      16,
    "cpuUsagePct":   32.4,
    "memTotalMib":   65536,
    "memUsedMib":    18432,
    "diskTotalGib":  2000,
    "diskUsedGib":   340,
    "netRxMbps":     1240.0,
    "netTxMbps":     870.0,
    "loadScore":     0.28,
    "vmCount":       3,
    "uptimeSecs":    86400
  }
]
```

**Status values:** `HEALTHY`, `HIGH_LOAD`, `CRITICAL`

---

### GET /api/cluster — Cluster overview

Combined view of nodes, VMs, and DRS metrics.

```bash
curl http://localhost:8765/api/cluster | jq .
```

**Response (200):**

```json
{
  "nodes":             [ ...node objects... ],
  "vms":               [ ...vm objects... ],
  "balanceSigma":      0.08,
  "drsMode":           "FullyAutomated",
  "totalCpuPct":       32.4,
  "totalMemPct":       28.1,
  "xdpThroughputGbps": 2.4,
  "xdpDropsTotal":     0
}
```

---

## DRS

### GET /api/drs/recommendations — DRS recommendations

```bash
curl http://localhost:8765/api/drs/recommendations | jq .
```

**Response (200):**

```json
{
  "recommendations": [
    {
      "vmId":    "vm-a1b2c3d4",
      "vmName":  "web-01",
      "fromNode": "caiman-node-01",
      "toNode":   "caiman-node-02",
      "score":    0.87,
      "reason":   "CPU imbalance σ=0.14 > threshold 0.10"
    }
  ],
  "balanceSigma": 0.14
}
```

---

## WebSocket

Connect to `ws://localhost:8765/ws` for live metrics.

```javascript
const ws = new WebSocket('wss://api.caimanos.com/ws');
ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  // msg.type: "VmMetricsUpdate" | "NodeMetricsUpdate" | "VmStatusChange"
  console.log(msg);
};
```

**Message types:**

```json
// VmMetricsUpdate — every 5 seconds
{
  "type": "VmMetricsUpdate",
  "vmId": "vm-a1b2c3d4",
  "cpuUsagePct": 32.4,
  "memUsedMib": 128,
  "netRxMbps": 1.24,
  "netTxMbps": 0.87
}

// VmStatusChange — on status transitions
{
  "type": "VmStatusChange",
  "vmId": "vm-a1b2c3d4",
  "from": "BOOTING",
  "to":   "RUNNING"
}
```

---

## Error responses

All errors return JSON with an `error` field:

```json
{ "error": "VM vm-a1b2c3d4 not found" }
```

| Status | Meaning |
|--------|---------|
| 400 | Bad request — invalid JSON or missing required field |
| 404 | Resource not found |
| 409 | Conflict — VM already running |
| 500 | Internal server error — check `docker logs caimanapi` |

---

## CLI examples

Using the `caiman` CLI (installed with `caiman-cli`):

```bash
# List VMs
caiman vm list

# Create VM
caiman vm create --name web-01 --cpus 2 --mem 512

# Stop VM
caiman vm stop vm-a1b2c3d4

# Stream serial console
caiman vm console vm-a1b2c3d4

# Migrate VM
caiman vm migrate vm-a1b2c3d4 --to 192.168.1.42

# DRS status
caiman drs status

# Execute DRS recommendations
caiman drs exec
```
