//! storage — stub module
