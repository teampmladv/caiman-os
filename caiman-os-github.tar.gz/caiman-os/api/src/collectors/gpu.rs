//! collectors/gpu.rs — stub collector
use anyhow::Result;

pub async fn collect() -> Result<()> {
    Ok(())
}
