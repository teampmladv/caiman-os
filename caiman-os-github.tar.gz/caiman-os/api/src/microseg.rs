//! microseg — stub module
