//! gpu — stub module
